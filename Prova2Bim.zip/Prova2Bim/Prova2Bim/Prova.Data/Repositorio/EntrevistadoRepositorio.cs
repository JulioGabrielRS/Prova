using Prova2Bim.Dominio.Entidades;
using Prova2Bim.Dominio.Interfaces;
using Prova2Bim.Data.Context;

namespace Prova2Bim.Data.Repositorio;

public class EntrevistadoRepositorio : IEntrevistadoRepositorio
{
    private readonly AppDbContext _context;

    public EntrevistadoRepositorio(AppDbContext context)
    {
        _context = context;
    }

    public void Criar(Entrevistado entrevistado)
    {
        _context.Entrevistados.Add(entrevistado);
        _context.SaveChanges();
    }

    public void Atualizar(Entrevistado entrevistado)
    {
        _context.Entrevistados.Update(entrevistado);
        _context.SaveChanges();
    }

    public Entrevistado? BuscarPorCpf(string cpf)
    {
        return _context.Entrevistados.FirstOrDefault(e => e.CPF == cpf);
    }

    public List<Entrevistado> BuscarTodos()
    {
        return _context.Entrevistados.ToList();
    }

}

using Microsoft.EntityFrameworkCore;
using Prova2Bim.Dominio.Entidades;

namespace Prova2Bim.Data.Context;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Entrevistado> Entrevistados { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Entrevistado>(entity =>
        {
            entity.ToTable("Entrevistados");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd();

            entity.Property(e => e.Nome)
                .IsRequired()
                .HasMaxLength(200);

            entity.Property(e => e.Idade)
                .IsRequired();

            entity.Property(e => e.CPF)
                .IsRequired()
                .HasMaxLength(11);

            entity.Property(e => e.EstaEmpregado)
                .IsRequired();

            entity.Property(e => e.DescricaoEmprego)
                .IsRequired()
                .HasMaxLength(500);

            entity.Property(e => e.MoraAluguel)
                .IsRequired();

            entity.Property(e => e.ValorAluguel)
                .IsRequired()
                .HasColumnType("decimal(18,2)");

            entity.Property(e => e.ContatoTelefonico)
                .IsRequired()
                .HasMaxLength(20);
        });
    }
}

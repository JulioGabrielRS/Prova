using Microsoft.EntityFrameworkCore;
using Prova2Bim.Application.Services;
using Prova2Bim.Data.Context;
using Prova2Bim.Data.Repositorio;
using Prova2Bim.Dominio.Interfaces;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.AddScoped<IEntrevistadoRepositorio, EntrevistadoRepositorio>();
builder.Services.AddScoped<IEntrevistadoServico, EntrevistadoServico>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

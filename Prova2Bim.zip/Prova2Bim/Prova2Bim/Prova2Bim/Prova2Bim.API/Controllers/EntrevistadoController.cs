using Microsoft.AspNetCore.Mvc;
using Prova2Bim.Dominio.Entidades;
using Prova2Bim.Dominio.Interfaces;

namespace Prova2Bim.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EntrevistadoController : ControllerBase
{
    private readonly IEntrevistadoServico _servico;

    public EntrevistadoController(IEntrevistadoServico servico)
    {
        _servico = servico;
    }

    [HttpPost]
    public IActionResult Criar([FromBody] Entrevistado entrevistado)
    {
        try
        {
            _servico.Criar(entrevistado);
            return Ok(new { mensagem = "Entrevistado criado com sucesso." });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { erro = ex.Message });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { erro = "Erro ao criar entrevistado.", detalhes = ex.Message });
        }
    }

    [HttpPut]
    public IActionResult Atualizar([FromBody] Entrevistado entrevistado)
    {
        try
        {
            _servico.Atualizar(entrevistado);
            return Ok(new { mensagem = "Entrevistado atualizado com sucesso." });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { erro = ex.Message });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { erro = "Erro ao atualizar entrevistado.", detalhes = ex.Message });
        }
    }

    [HttpGet("cpf/{cpf}")]
    public IActionResult BuscarPorCpf(string cpf)
    {
        try
        {
            var entrevistado = _servico.BuscarPorCpf(cpf);
            if (entrevistado == null)
            {
                return NotFound(new { erro = "Entrevistado n�o encontrado." });
            }
            return Ok(entrevistado);
        }
        catch (Exception ex)
        {
            return BadRequest(new { erro = "Erro ao buscar entrevistado.", detalhes = ex.Message });
        }
    }

    [HttpGet]
    public IActionResult BuscarTodos()
    {
        try
        {
            var entrevistados = _servico.BuscarTodos();
            return Ok(entrevistados);
        }
        catch (Exception ex)
        {
            return BadRequest(new { erro = "Erro ao buscar entrevistados.", detalhes = ex.Message });
        }
    }
}

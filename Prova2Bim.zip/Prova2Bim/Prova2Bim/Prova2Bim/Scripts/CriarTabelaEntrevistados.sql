-- Script de cria��o da tabela Entrevistados
-- Banco de dados: SQL Server

CREATE TABLE Entrevistados (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nome NVARCHAR(200) NOT NULL,
    Idade INT NOT NULL,
    CPF NVARCHAR(11) NOT NULL,
    EstaEmpregado BIT NOT NULL,
    DescricaoEmprego NVARCHAR(500) NOT NULL,
    MoraAluguel BIT NOT NULL,
    ValorAluguel DECIMAL(18, 2) NOT NULL,
    ContatoTelefonico NVARCHAR(20) NOT NULL
);

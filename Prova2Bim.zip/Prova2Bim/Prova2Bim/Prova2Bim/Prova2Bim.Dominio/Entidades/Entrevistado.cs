namespace Prova2Bim.Dominio.Entidades;

public class Entrevistado
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public int Idade { get; set; }
    public string CPF { get; set; }
    public bool EstaEmpregado { get; set; }
    public string DescricaoEmprego { get; set; }
    public bool MoraAluguel { get; set; }
    public decimal ValorAluguel { get; set; }
    public string ContatoTelefonico { get; set; }
}

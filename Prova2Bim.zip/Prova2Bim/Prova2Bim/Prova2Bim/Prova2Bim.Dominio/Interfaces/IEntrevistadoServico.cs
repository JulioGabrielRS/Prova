using Prova2Bim.Dominio.Entidades;

namespace Prova2Bim.Dominio.Interfaces;

public interface IEntrevistadoServico
{
    void Criar(Entrevistado entrevistado);
    void Atualizar(Entrevistado entrevistado);
    Entrevistado? BuscarPorCpf(string cpf);
    List<Entrevistado> BuscarTodos();
}

using Prova2Bim.Dominio.Entidades;
using Prova2Bim.Dominio.Interfaces;

namespace Prova2Bim.Application.Services;

public class EntrevistadoServico : IEntrevistadoServico
{
    private readonly IEntrevistadoRepositorio _repositorio;

    public EntrevistadoServico(IEntrevistadoRepositorio repositorio)
    {
        _repositorio = repositorio;
    }

    public void Criar(Entrevistado entrevistado)
    {
        var entrevistadoExistente = _repositorio.BuscarPorCpf(entrevistado.CPF);
        if (entrevistadoExistente != null)
        {
            throw new InvalidOperationException("CPF j� cadastrado no sistema.");
        }

        if (entrevistado.MoraAluguel && entrevistado.ValorAluguel <= 0)
        {
            throw new InvalidOperationException("ValorAluguel � obrigat�rio quando MoraAluguel � verdadeiro.");
        }

        _repositorio.Criar(entrevistado);
    }

    public void Atualizar(Entrevistado entrevistado)
    {
        if (entrevistado.MoraAluguel && entrevistado.ValorAluguel <= 0)
        {
            throw new InvalidOperationException("ValorAluguel � obrigat�rio quando MoraAluguel � verdadeiro.");
        }

        _repositorio.Atualizar(entrevistado);
    }

    public Entrevistado? BuscarPorCpf(string cpf)
    {
        return _repositorio.BuscarPorCpf(cpf);
    }

    public List<Entrevistado> BuscarTodos()
    {
        return _repositorio.BuscarTodos();
    }

}
